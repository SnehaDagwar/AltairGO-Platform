# Brand Spec: Altair GO

## Color Palette (OKLch)
- **Primary (Cool Cerulean):** `oklch(73% 0.07 235)` (#8EB1D1)
- **Secondary (Baby Blue):** `oklch(80% 0.07 240)` (#A7C7E7)
- **Surface (Platinum):** `oklch(94% 0.01 245)` (#E8ECEF)
- **Background (Light Blue Grey):** `oklch(86% 0.03 245)` (#C4D8E5)
- **Deep (Midnight Blue):** `oklch(25% 0.06 255)` (#1C2B48)
- **White (Clean Pearl):** `oklch(99% 0.005 240)` (#F8FAFC)

## Typography
- **Display/Heading:** Modern Geometric Sans-serif (Inter/Montserrat inspiration from `mpammvwq-image.png`)
- **Accents:** Brush/Script Font (Satisfy/Dancing Script style)
- **UI/Body:** Poppins (Geometric & Friendly)

## Posture & Logic
- **Aesthetic:** Glassmorphism + Premium Startup
- **Borders:** Hairline (1px) with low opacity white/midnight
- **Radii:** Consistent 16px - 24px for a soft, premium feel
- **Shadows:** Soft, layered cerulean-tinted shadows
- **Tone:** Luxury minimal. High contrast typography with generous whitespace.
