# Altair GO — Typography Specification (v4.0 Cinematic)

> *Exact typography system inspired by Unikorns.work.*

## 1. Primary Typography System

| Role | Font Family | Characteristics |
| :--- | :--- | :--- |
| **Display (Headings & Hero)** | **Instrument Serif** | Elegant, modern serif used for high-impact cinematic moments. Adds editorial luxury. |
| **Interface (Body, UI, Nav)** | **Aeonik** | Clean, minimalist, modern sans-serif. Highly legible and structurally precise. |
| **Accent (Travel)** | **Satisfy** | Kept from existing branding for signature moments and human touch. |

---

## 2. Usage Guidelines (Serif vs. Sans-Serif)

**Instrument Serif** is reserved strictly for:
- Large cinematic hero text (H1)
- Major section titles (H2)
- Pull quotes or editorial spotlight moments
*Rule: Never use Instrument Serif for functional UI elements, buttons, or paragraphs.*

**Aeonik** is used for everything else:
- Body text and paragraphs
- Navigation menus
- Buttons and CTAs
- Data, cards, inputs, and small labels
*Rule: Aeonik drives the functional SaaS side of the product.*

---

## 3. Heading Scale (Cinematic / Editorial)

| Level | Font Family | Size (Desktop) | Weight | Letter-Spacing | Line-Height | Case |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **H1 (Hero)** | Instrument Serif | 5rem – 7rem | 400 (Regular / Italic) | `-0.02em` | 1.05 | Sentence / Title |
| **H2 (Section)** | Instrument Serif | 3rem – 4rem | 400 (Regular) | `-0.01em` | 1.1 | Sentence |
| **H3 (Subhead)** | Aeonik | 1.5rem | 500 (Medium) | `0` | 1.3 | Sentence |
| **H4–H6** | Aeonik | 1.125rem+ | 700 (Bold) | `0.01em` | 1.4 | Sentence |

---

## 4. Body & UI Styles

| Style | Font Family | Size | Weight | Line-Height | Tracking |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Body Large** | Aeonik | 1.125rem (18px) | 400 | 1.6 | Normal |
| **Body Base** | Aeonik | 1rem (16px) | 400 | 1.6 | Normal |
| **Body Small** | Aeonik | 0.875rem (14px) | 400 | 1.5 | Normal |
| **Utility/Label**| Aeonik | 0.75rem (12px) | 500 / 700 | 1.4 | `0.04em` (Uppercase) |

---

## 5. Component Typography

### Buttons & CTAs
- **Font:** Aeonik
- **Size:** 0.9375rem (15px) or 1rem (16px)
- **Weight:** 500 (Medium)
- **Transform:** Sentence Case
- **Tracking:** `0` or `0.01em`

### Cards & Navigation
- **Font:** Aeonik
- **Titles:** Aeonik 500/700, 1.25rem
- **Nav Links:** Aeonik 400, 0.9375rem, hover states with subtle weight shifts or opacity changes.

---

## 6. Implementation Rules (Antigravity/Tailwind)

### Font Imports
*Instrument Serif* is available via Google Fonts. *Aeonik* requires custom `@font-face` hosting (or Adobe Fonts/Typekit equivalent if licensed).

```html
<!-- In <head> -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Satisfy&display=swap" rel="stylesheet">
```

### Tailwind Config

```javascript
// tailwind.config.js refinement
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        display: ['"Instrument Serif"', 'serif'],
        body: ['Aeonik', 'sans-serif'],
        accent: ['Satisfy', 'cursive'],
      },
      fontSize: {
        'hero': ['clamp(4rem, 8vw, 7rem)', { lineHeight: '1.05', letterSpacing: '-0.02em', fontWeight: '400' }],
      },
      letterSpacing: {
        'cinematic': '-0.02em',
        'premium': '-0.01em',
      }
    }
  }
}
```

## 7. Responsive Typography Rules
- **Fluid Scaling:** Use `clamp()` for H1 and H2 to ensure headings scale down gracefully on mobile without breaking layouts (e.g., `clamp(3rem, 8vw, 6rem)`).
- **Mobile Adjustments:** Tighten line-height on mobile (from 1.6 to 1.5) for body text to save vertical space.
- **Hierarchy Preservation:** Even when scaled down, the contrast between the serif display (Instrument Serif) and sans-serif functional text (Aeonik) must remain distinct and intentional.